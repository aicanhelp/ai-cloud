package org.mds.ray.domain.kuberay.job;

public class RayJob {
}
