package org.mds.ray.domain.kubernetes.cluster;

public class K8sRayCluster {
}
