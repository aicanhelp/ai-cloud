package org.mds.ray.domain.kuberay.cluster;

import org.mds.ray.domain.kuberay.RayResourceBase;

public class RayCluster extends RayResourceBase {

}
