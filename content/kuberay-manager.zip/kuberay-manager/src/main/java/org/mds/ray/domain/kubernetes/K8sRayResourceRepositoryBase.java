package org.mds.ray.domain.kubernetes;

import org.mds.ray.domain.kuberay.RayResourceBase;

public interface K8sRayResourceRepositoryBase<T extends K8sRayResourceBase> {

}
