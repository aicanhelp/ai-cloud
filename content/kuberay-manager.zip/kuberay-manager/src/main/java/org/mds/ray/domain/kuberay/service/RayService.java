package org.mds.ray.domain.kuberay.service;

public class RayService {
}
