package org.mds.ray.domain.kuberay;

public interface RayResourceRepositoryBase<T extends RayResourceBase> {

}
